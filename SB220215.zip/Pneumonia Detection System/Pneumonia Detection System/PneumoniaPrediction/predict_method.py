import pickle
from docxtpl import DocxTemplate
import datetime
#from docx2pdf import convert
import os
from PneumoniaPrediction import app
from tensorflow.keras.models import load_model
import cv2
import numpy as np

model_path ='PneumoniaPrediction/models/pneumonia_model.h5'
model=load_model(model_path)

current_date= datetime.datetime.now().strftime("%d/%m/%Y")

def  predict_disease(id,name,img):
    img_size=150
    img_arr = cv2.imread(img, cv2.IMREAD_GRAYSCALE)
    resized_arr = cv2.resize(img_arr, (img_size, img_size))
    x = np.array(resized_arr) / 255
    x = x.reshape(-1, img_size, img_size, 1)
    preds=np.round(model.predict(x))
    if os.path.exists(img):
        os.remove(img)
    if preds == 0:
        message="suffering"
        result=[id,name,message]
        return result
    else:
        message="not suffering"
        result=[id,name,message]
        return result


def report_generate(output):
    doc=DocxTemplate(os.path.join(app.config['reporttemplate'],'template.docx'))
    context = {'patientid':output[0],'name':output[1],'gender':output[2],'age':output[3],'phone':output[4],'address':output[5],'dname':output[6],'dt':current_date,'message':output[7]}
    doc.render(context)
    path1 = os.path.join(app.config['Reports'],output[0]+'.docx')
    #path2 = os.path.join(app.config['Reports'],output[0]+'.pdf')
    doc.save(path1)
    #convert(path1,path2)
    #os.remove(path1)
    return path1

