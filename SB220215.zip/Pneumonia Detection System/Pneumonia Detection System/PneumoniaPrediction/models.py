from PneumoniaPrediction import db,login_manager,app
from flask_login import UserMixin
from flask import session

@login_manager.user_loader
def load_user(id):
    type = session.get('type')
    if type == 'Doctor':
        user = Doctor.query.filter_by(id = id).first()
    elif type == 'Receptionist':
        user = Receptionist.query.filter_by(id = id).first()
    else:
        user = None
    return user


class DoctorApproval(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uprn=db.Column(db.String(10), unique=True,nullable=False)
    username = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(10), nullable=False)
    city = db.Column(db.String(40), nullable=False)
    image_file = db.Column(db.String(20), nullable=False, default='default.jpg')
    password = db.Column(db.String(60), nullable=False)

    def __repr__(self):
        return f"Approval('{self.username}', '{self.email}', '{self.image_file}')"
    
class ReceptionistApproval(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(10), nullable=False)
    city = db.Column(db.String(40), nullable=False)
    image_file = db.Column(db.String(20), nullable=False, default='default.jpg')
    password = db.Column(db.String(60), nullable=False)

    def __repr__(self):
        return f"Approval('{self.username}', '{self.email}', '{self.image_file}')"
    
class Doctor(db.Model,UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    uprn=db.Column(db.String(10), unique=True,nullable=False)
    username = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(10), nullable=False)
    city = db.Column(db.String(40), nullable=False)
    image_file = db.Column(db.String(20), nullable=False, default='default.jpg')
    password = db.Column(db.String(60), nullable=False)

    def __repr__(self):
        return f"User('{self.username}', '{self.email}', '{self.image_file}')"
    
class Receptionist(db.Model,UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(10), nullable=False)
    city = db.Column(db.String(40), nullable=False)
    image_file = db.Column(db.String(20), nullable=False, default='default.jpg')
    password = db.Column(db.String(60), nullable=False)

    def __repr__(self):
        return f"User('{self.username}', '{self.email}', '{self.image_file}')"
    
class Patient(db.Model,UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    patientid=db.Column(db.String(20), nullable=False)
    patientname = db.Column(db.String(30), nullable=False)
    sex = db.Column(db.String(10), nullable=False)
    age = db.Column(db.String(10), nullable=False)
    phone = db.Column(db.String(10), nullable=False)
    address = db.Column(db.String(100), nullable=False)
    report = db.Column(db.String(20), nullable=True)
    password = db.Column(db.String(60), nullable=True)
    def __repr__(self):
        return f"User('{self.patientid}''{self.patientname}', )"

class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)

    def __repr__(self):
        return f"Admin('{self.email}')"
    
class ReceptionistMessages(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), nullable=False)
    subject=db.Column(db.String(100), nullable=False)
    message = db.Column(db.String(150),nullable=False)
    
    def __repr__(self):
        return f"Messages('{self.email},'{self.subject}','{self.message}')"
    
class DoctorMessages(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), nullable=False)
    subject=db.Column(db.String(100), nullable=False)
    message = db.Column(db.String(150),nullable=False)
    
    def __repr__(self):
        return f"Messages('{self.email},'{self.subject}','{self.message}')"

           
with app.app_context():
    db.create_all()
