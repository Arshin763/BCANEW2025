from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField,SelectField
from flask_wtf.file import FileField, FileAllowed
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError
from PneumoniaPrediction.models import DoctorApproval,ReceptionistApproval,Doctor,Receptionist,Patient
from flask_login import current_user

class AdminLoginForm(FlaskForm):
    email = StringField(validators=[DataRequired(), Email()],render_kw={"placeholder": "Email address"})                    
    password = PasswordField(validators=[DataRequired()],render_kw={"placeholder": "Password"})
    submit = SubmitField('Login')

class DoctorRegistrationForm(FlaskForm):
    uprn = StringField(validators=[DataRequired(), Length(min=4, max=10)],
                           render_kw={"placeholder": "Unique Personal Registration Number"})
    username = StringField(validators=[DataRequired(), Length(min=2, max=20)],
                           render_kw={"placeholder": "Username"})
    email = StringField(validators=[DataRequired(), Email()],
                        render_kw={"placeholder": "Email address"})
    phone = StringField(validators=[DataRequired(), Length(min=10, max=10)],
                           render_kw={"placeholder": "Mobile Number"})
    city = StringField(validators=[DataRequired(), Length(min=2, max=30)],
                           render_kw={"placeholder": "City"})
    password = PasswordField(validators=[DataRequired()],
                             render_kw={"placeholder": "Password"})
    confirm_password = PasswordField(validators=[DataRequired(), EqualTo('password')],
                                     render_kw={"placeholder": "Confirm Password"})
    submit = SubmitField('Sign Up')
    
    def validate_phone(self,phone):
        try:
            number=int(phone.data)
        except ValueError: 
            raise ValidationError("Please check your mobile number")
    def validate_urpn(self,uprn):
        try:
            number=int(uprn.data)
        except ValueError: 
            raise ValidationError("Please check your UPRN")
            
    def validate_email(self, email):
        user =DoctorApproval.query.filter_by(email=email.data).first()
        user1=Doctor.query.filter_by(email=email.data).first()
        if user or user1:
            raise ValidationError('That email is taken. Please choose a different one.')
        
class DoctorLoginForm(FlaskForm):
    email = StringField(validators=[DataRequired(), Email()],render_kw={"placeholder": "Email address"})                    
    password = PasswordField(validators=[DataRequired()],render_kw={"placeholder": "Password"})
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')
    
class ReceptionistRegistrationForm(FlaskForm):
    username = StringField(validators=[DataRequired(), Length(min=2, max=20)],
                           render_kw={"placeholder": "Username"})
    email = StringField(validators=[DataRequired(), Email()],
                        render_kw={"placeholder": "Email address"})
    phone = StringField(validators=[DataRequired(), Length(min=10, max=10)],
                           render_kw={"placeholder": "Mobile Number"})
    city = StringField(validators=[DataRequired(), Length(min=2, max=30)],
                           render_kw={"placeholder": "City"})
    password = PasswordField(validators=[DataRequired()],
                             render_kw={"placeholder": "Password"})
    confirm_password = PasswordField(validators=[DataRequired(), EqualTo('password')],
                                     render_kw={"placeholder": "Confirm Password"})
    submit = SubmitField('Sign Up')
    
    def validate_phone(self,phone):
        try:
            number=int(phone.data)
        except ValueError: 
            raise ValidationError("Please check your mobile number")
            
    def validate_email(self, email):
        user =ReceptionistApproval.query.filter_by(email=email.data).first()
        user1=Receptionist.query.filter_by(email=email.data).first()
        if user or user1:
            raise ValidationError('That email is taken. Please choose a different one.')
        
class ReceptionistLoginForm(FlaskForm):
    email = StringField(validators=[DataRequired(), Email()],render_kw={"placeholder": "Email address"})                    
    password = PasswordField(validators=[DataRequired()],render_kw={"placeholder": "Password"})
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')
    
    
class ChangePassword(FlaskForm):                    
    current_password = PasswordField(validators=[DataRequired()],render_kw={"placeholder": "Current Password"})
    new_password = PasswordField(validators=[DataRequired()],render_kw={"placeholder": "New Password"})
    submit = SubmitField('Change')

    
class UpdateDoctorAccountForm(FlaskForm):
    uprn = StringField(validators=[DataRequired(), Length(min=4, max=10)])
    username = StringField(validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField(validators=[DataRequired(), Email()])
    picture = FileField(validators=[FileAllowed(['jpg','jpeg', 'png'])])
    phone = StringField(validators=[DataRequired(), Length(min=10, max=10)])
    city = StringField(validators=[DataRequired(), Length(min=2, max=30)])
    submit = SubmitField('Update')

    def validate_email(self, email):
        if email.data != current_user.email:
            user =DoctorApproval.query.filter_by(email=email.data).first()
            user1=Doctor.query.filter_by(email=email.data).first()
            if user:
                raise ValidationError('That email is taken. Please choose a different one.')
                
            if user1:
                raise ValidationError('That email is taken. Please choose a different one.')
                
    def validate_phone(self,phone):
        try:
            number=int(phone.data)
        except ValueError: 
            raise ValidationError("Please check your mobile number")
        
    def validate_urpn(self,uprn):
        try:
            number=int(uprn.data)
        except ValueError: 
            raise ValidationError("Please check your URPN")
        
class UpdateReceptionistAccountForm(FlaskForm):
    username = StringField(validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField(validators=[DataRequired(), Email()])
    picture = FileField(validators=[FileAllowed(['jpg','jpeg', 'png'])])
    phone = StringField(validators=[DataRequired(), Length(min=10, max=10)])
    city = StringField(validators=[DataRequired(), Length(min=2, max=30)])
    submit = SubmitField('Update')

    def validate_email(self, email):
        if email.data != current_user.email:
            user =ReceptionistApproval.query.filter_by(email=email.data).first()
            user1=Receptionist.query.filter_by(email=email.data).first()
            if user:
                raise ValidationError('That email is taken. Please choose a different one.')
                
            if user1:
                raise ValidationError('That email is taken. Please choose a different one.')
                
    def validate_phone(self,phone):
        try:
            number=int(phone.data)
        except ValueError: 
            raise ValidationError("Please check your mobile number")
    
class AddPatientForm(FlaskForm):
    patientid = StringField(validators=[DataRequired(), Length(min=1)],
                           render_kw={"placeholder": ""})
    patientname = StringField(validators=[DataRequired(), Length(min=2, max=20)],
                           render_kw={"placeholder": ""})
    sex = SelectField('Choose gender',choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')])
    age = StringField(validators=[DataRequired(), Length(min=1, max=3)],
                           render_kw={"placeholder": ""})
    phone = StringField(validators=[DataRequired(), Length(min=10, max=10)],
                           render_kw={"placeholder": ""})
    address = StringField(validators=[DataRequired(), Length(min=2, max=100)],
                           render_kw={"placeholder": ""})
    submit = SubmitField('ADD')

    def validate_patientidnum(self, patientid):
        try:
            number=int(patientid.data)
        except ValueError: 
            raise ValidationError("Please check your Patient Id.") 
            
    def validate_patientid(self, patientid):
        if patientid.data:
            patient =Patient.query.filter_by(patientid=patientid.data).first()
            if patient:
                raise ValidationError('PatientId already exist.')
                
    
    def validate_phone(self,phone):
        try:
            number=int(phone.data)
        except ValueError: 
            raise ValidationError("Please check your mobile number")
    
    def validate_age(self,age):
        try:
            number=int(age.data)
            if number < 0:
                raise ValidationError("Please enter proper age")
        except ValueError: 
            raise ValidationError("Please enter proper age")
        
class PatientSearchForm(FlaskForm):
    patientid = StringField(validators=[DataRequired(), Length(min=1)],
                           render_kw={"placeholder": ""})
    submit = SubmitField('Search')
    def validate_patientid(self, patientid):
        if patientid.data:
            patient =Patient.query.filter_by(patientid=patientid.data).first()
            if not patient:
                raise ValidationError('PatientId does exist.')