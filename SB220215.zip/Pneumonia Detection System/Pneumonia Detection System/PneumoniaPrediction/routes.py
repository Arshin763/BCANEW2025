from flask import render_template, url_for, flash, redirect,request,session,Response,send_file,send_from_directory
from PneumoniaPrediction import app , db, bcrypt,func
from werkzeug.utils import secure_filename
from PneumoniaPrediction.forms import PatientSearchForm,AddPatientForm,DoctorLoginForm ,ReceptionistLoginForm,AdminLoginForm, DoctorRegistrationForm,ReceptionistRegistrationForm,ChangePassword,UpdateDoctorAccountForm,UpdateReceptionistAccountForm
from PneumoniaPrediction.models import Patient,DoctorApproval,ReceptionistApproval,Receptionist,Doctor, Admin,DoctorMessages,ReceptionistMessages
from flask_login import login_user, current_user, logout_user, login_required
from PneumoniaPrediction.predict_method import predict_disease,report_generate
import numpy as np
import pythoncom
import secrets
import os
from PIL import Image

#from flask_login import login_user, current_user, logout_user, login_required

ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
pythoncom.CoInitialize()
    
@app.route("/")
@app.route("/home")
def home():
    if not Admin.query.all():
        pwd='Admin@PPS'
        pswrd=bcrypt.generate_password_hash(pwd).decode('utf-8')
        user = Admin(email='admin@pps.com',password=pswrd)
        db.session.add(user)
        db.session.commit()
    return render_template('home.html', title='Home')

@app.route("/adminlogin", methods=['GET', 'POST'])
def adminlogin():
    form = AdminLoginForm()
    if form.validate_on_submit():
        admin=Admin.query.filter_by(email=form.email.data).first()
        if admin and bcrypt.check_password_hash(admin.password, form.password.data):
            flash('hello Admin... \n You have been logged in!', 'success')
            session.permanent = True
            session['type'] = 'admin'
            return redirect(url_for('adminhome'))
        else:
            flash('Login Unsuccessful. Please check Email address and password', 'danger')
    return render_template('adminlogin.html', title='Login', form=form)

@app.route("/adminhome")
def adminhome():
    return render_template('adminhome.html', title='Home')

@app.route("/doctorhome")
def doctorhome():
    return render_template('doctorhome.html', title='Home')

@app.route("/doctorregister", methods=['GET', 'POST'])
def doctorregister():
    form = DoctorRegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        doctor = DoctorApproval(uprn=form.uprn.data,username=form.username.data, email=form.email.data, phone=form.phone.data,
                        city=form.city.data, password=hashed_password)
        db.session.add(doctor)
        db.session.commit()
        flash('Your request for the registration will be processed with in 24 hours!', 'success')
        return redirect(url_for('doctorlogin'))
    return render_template('doctorregister.html', title='Registration Form', form=form)

@app.route("/receptionistregister", methods=['GET', 'POST'])
def receptionistregister():
    form = ReceptionistRegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        reception = ReceptionistApproval(username=form.username.data, email=form.email.data, phone=form.phone.data,
                        city=form.city.data, password=hashed_password)
        db.session.add(reception)
        db.session.commit()
        flash('Your request for the registration will be processed with in 24 hours!', 'success')
        return redirect(url_for('doctorlogin'))
    return render_template('receptionistregister.html', title='Registration Form', form=form)

@app.route("/doctorlogin", methods=['GET', 'POST'])
def doctorlogin():
    if current_user.is_authenticated:
        return redirect(url_for('doctorhome'))
    form = DoctorLoginForm()
    if form.validate_on_submit():
        doctor1 = DoctorApproval.query.filter_by(email=form.email.data).first()
        doctor=Doctor.query.filter_by(email=form.email.data).first()
        if doctor1:
            flash('Your request for registration is pending, please try after sometimes..', 'info')
            return redirect(url_for('doctorlogin'))
        elif not doctor:
            flash('You are not registered.','info')
            return redirect(url_for('doctorregister'))
        elif doctor and bcrypt.check_password_hash(doctor.password, form.password.data):
            login_user(doctor, remember=form.remember.data)
            session.permanent = True
            session['type'] = 'Doctor'
            flash('Logged in successfully..!','success')
            return redirect(url_for('doctorhome'))
        else:
            flash('Please check your password..','danger')
            return redirect(url_for('doctorlogin'))
    return render_template('doctorlogin.html',title='Login',form=form)

@app.route("/receptionistlogin", methods=['GET', 'POST'])
def receptionistlogin():
    if current_user.is_authenticated:
        return redirect(url_for('receptionisthome'))
    form = ReceptionistLoginForm()
    if form.validate_on_submit():
        reception1 = ReceptionistApproval.query.filter_by(email=form.email.data).first()
        reception=Receptionist.query.filter_by(email=form.email.data).first()
        if reception1:
            flash('Your request for registration is pending, please try after sometimes..', 'info')
            return redirect(url_for('receptionlogin'))
        elif not reception:
            flash('You are not registered.','info')
            return redirect(url_for('receptionistregister'))
        elif reception and bcrypt.check_password_hash(reception.password, form.password.data):
            login_user(reception, remember=form.remember.data)
            session.permanent = True
            session['type'] = 'Receptionist'
            flash('Logged in successfully..!','success')
            return redirect(url_for('receptionisthome'))
        else:
            flash('Please check your password..','danger')
            return redirect(url_for('receptionistlogin'))
    return render_template('receptionistlogin.html',title='Login',form=form)

@app.route("/receptionisthome")
def receptionisthome():
    return render_template('receptionisthome.html', title='Home')

@app.route("/usersdetails")
def usersdetails():
    doctor=Doctor.query.all()
    receptionist=Receptionist.query.all()
    return render_template('usersdetails.html', title='Users Details',results=[doctor,receptionist])

@app.route("/deletedoctor/<int:id>")
def deletedoctor(id):
    doctor=Doctor.query.get_or_404(id)
    db.session.delete(doctor)
    db.session.commit()
    return redirect(url_for('usersdetails'))

@app.route("/deletereceptionist/<int:id>")
def deletereceptionist(id):
    receptionist=Receptionist.query.get_or_404(id)
    db.session.delete(receptionist)
    db.session.commit()
    return redirect(url_for('usersdetails'))

@app.route("/changepassword",methods=['GET','POST'])
def changepassword():
    form=ChangePassword()
    if form.validate_on_submit():
        record=Admin.query.all()[0]
        if bcrypt.check_password_hash(record.password,form.current_password.data):
            record.password=bcrypt.generate_password_hash(form.new_password.data).decode('utf-8')
            db.session.commit()
            flash('Password changed successfully..!', 'success')
            return redirect(url_for('adminhome'))
        else:
            flash('Please enter correct current password', 'danger')
    return render_template('changepswrd.html', title='Change Password',form=form)
 
@app.route("/memberrequests")
def memberrequests():
    doctor1=DoctorApproval.query.all()
    receptionist1=ReceptionistApproval.query.all()
    return render_template('memberrequests.html', title='RegistrationRequests',results=[doctor1,receptionist1])

@app.route("/doctorapproved/<int:id>")
def doctorapproved(id):
    user1=DoctorApproval.query.get_or_404(id)
    db.session.delete(user1)
    user2 = Doctor(uprn=user1.uprn,username=user1.username, email=user1.email, phone=user1.phone,
                        city=user1.city, image_file=user1.image_file, password=user1.password)
    db.session.add(user2)
    db.session.commit()
    return redirect(url_for('memberrequests'))

@app.route("/deletedoctorrequest/<int:id>")
def deletedoctorrequest(id):
    user1=DoctorApproval.query.get_or_404(id)
    db.session.delete(user1)
    db.session.commit()
    return redirect(url_for('memberrequests'))

@app.route("/receptionistapproved/<int:id>")
def receptionistapproved(id):
    user1=ReceptionistApproval.query.get_or_404(id)
    db.session.delete(user1)
    user2 = Receptionist(username=user1.username, email=user1.email, phone=user1.phone,
                        city=user1.city, image_file=user1.image_file, password=user1.password)
    db.session.add(user2)
    db.session.commit()
    return redirect(url_for('memberrequests'))

@app.route("/deletereceptionistrequest/<int:id>")
def deletereceptionistrequest(id):
    user1=ReceptionistApproval.query.get_or_404(id)
    db.session.delete(user1)
    db.session.commit()
    return redirect(url_for('memberrequests'))

@app.route("/adminmessageview")
def adminmessageview():
    result_doctor=DoctorMessages.query.all()
    result_receptionist = ReceptionistMessages.query.all()
    return render_template('adminmessageview.html', title='Messages',results=[result_doctor,result_receptionist])

@app.route("/receptionistmessagedelete/<int:id>")
def receptionistmessagedelete(id):
    msg=ReceptionistMessages.query.get_or_404(id)
    db.session.delete(msg)
    db.session.commit()
    flash("Message deleted duccessfully...!",'success')
    return redirect(url_for('adminmessageview'))

@app.route("/doctorprofile")
def doctorprofile(): 
    image_file = url_for('static', filename='profile/' + current_user.image_file)
    return render_template('doctorprofile.html', title='Profile',image=image_file)

@app.route("/receptionistprofile")
def receptionistprofile(): 
    image_file = url_for('static', filename='profile/' + current_user.image_file)
    return render_template('receptionistprofile.html', title='Profile',image=image_file)
    
@app.route("/doctoreditprofile",methods=['GET','POST'])
@login_required
def doctoreditprofile():
    form=UpdateDoctorAccountForm()
    if form.validate_on_submit():
        current_user.uprn=form.uprn.data
        current_user.email=form.email.data
        current_user.username= form.username.data
        current_user.phone = form.phone.data
        current_user.city= form.city.data
        if form.picture.data:
            picture_file = save_picture(form.picture.data)
            current_user.image_file = picture_file
        db.session.commit()
        flash('Your account has been updated!', 'success')
        return redirect(url_for('doctorprofile'))
    if request.method=='GET':
        form.uprn.data = current_user.uprn
        form.username.data=current_user.username
        form.email.data=current_user.email
        form.phone.data=current_user.phone
        form.city.data=current_user.city
        return render_template('doctoreditprofile.html', title='Profile',form=form)
    
@app.route("/receptionisteditprofile",methods=['GET','POST'])
@login_required
def receptionisteditprofile():
    form=UpdateReceptionistAccountForm()
    if form.validate_on_submit():
        current_user.email=form.email.data
        current_user.username= form.username.data
        current_user.phone = form.phone.data
        current_user.city= form.city.data
        if form.picture.data:
            picture_file = save_picture(form.picture.data)
            current_user.image_file = picture_file
        db.session.commit()
        flash('Your account has been updated!', 'success')
        return redirect(url_for('receptionistprofile'))
    if request.method=='GET':
        form.username.data=current_user.username
        form.email.data=current_user.email
        form.phone.data=current_user.phone
        form.city.data=current_user.city
        return render_template('receptionisteditprofile.html', title='Profile',form=form)

@app.route("/doctorchangepassword",methods=['GET','POST'])
def doctorchangepassword():
    form=ChangePassword()
    if form.validate_on_submit():
        if bcrypt.check_password_hash(current_user.password,form.current_password.data):
            current_user.password=bcrypt.generate_password_hash(form.new_password.data).decode('utf-8')
            db.session.commit()
            flash('Password changed successfully..!', 'success')
            return redirect(url_for('doctorhome'))
        else:
            flash('Please enter correct current password', 'danger')
    return render_template('doctorchangepassword.html', title='Change Password',form=form)

@app.route("/receptionistchangepassword",methods=['GET','POST'])
def receptionistchangepassword():
    form=ChangePassword()
    if form.validate_on_submit():
        if bcrypt.check_password_hash(current_user.password,form.current_password.data):
            current_user.password=bcrypt.generate_password_hash(form.new_password.data).decode('utf-8')
            db.session.commit()
            flash('Password changed successfully..!', 'success')
            return redirect(url_for('receptionisthome'))
        else:
            flash('Please enter correct current password', 'danger')
    return render_template('receptionistchangepassword.html', title='Change Password',form=form)

@app.route("/doctorcontactus",methods=['GET','POST'])
def doctorcontactus():
    if request.method=='POST':
        useremail=current_user.email
        sub=request.form['subject']
        msg=request.form['message']
        record=DoctorMessages(email=useremail,subject=sub,message=msg)
        db.session.add(record)
        db.session.commit()
        flash('your message sent successfully..!','success')
    return render_template('doctorcontactus.html', title='Contact us')

@app.route("/receptionistcontactus",methods=['GET','POST'])
def receptionistcontactus():
    if request.method=='POST':
        useremail=current_user.email
        sub=request.form['subject']
        msg=request.form['message']
        record=ReceptionistMessages(email=useremail,subject=sub,message=msg)
        db.session.add(record)
        db.session.commit()
        flash('your message sent successfully..!','success')
    return render_template('receptionistcontactus.html', title='Contact us')

@app.route("/adminlogout")
def adminlogout():
    logout_user()
    return redirect(url_for('home'))

@app.route("/doctorlogout")
def doctorlogout():
    logout_user()
    return redirect(url_for('home'))

@app.route("/receptionistlogout")
def receptionistlogout():
    logout_user()
    return redirect(url_for('home'))

@app.route("/receptionistaddpatient", methods=['GET', 'POST'])
def receptionistaddpatient():
    form=AddPatientForm()
    if form.validate_on_submit():
        patient = Patient(patientid=form.patientid.data,patientname=form.patientname.data,sex=form.sex.data,age=form.age.data,phone=form.phone.data,address=form.address.data)
        db.session.add(patient)
        db.session.commit()
        flash('Patient added successfully..!', 'success')
        return redirect(url_for('receptionistaddpatient'))
    return render_template('receptionistaddpatient.html', title='Add Patient',form=form)

@app.route("/doctoraddpatient", methods=['GET', 'POST'])
def doctoraddpatient():
    form=AddPatientForm()
    if form.validate_on_submit():
        patient = Patient(patientid=form.patientid.data,patientname=form.patientname.data,sex=form.sex.data,age=form.age.data,phone=form.phone.data,address=form.address.data)
        db.session.add(patient)
        db.session.commit()
        flash('Patient added successfully..!', 'success')
        return redirect(url_for('doctoraddpatient'))
    return render_template('doctoraddpatient.html', title='Add Patient',form=form)

@app.route("/viewdeletepatient", methods=['GET', 'POST'])
def viewdeletepatient():
    form = PatientSearchForm()
    if form.validate_on_submit():
        searchresult=Patient.query.filter_by(patientid=form.patientid.data).first()
        return render_template('viewdeletepatient.html', title='Patient\'s Details',searchresults=searchresult,form=form)
    patient=Patient.query.all()
    return render_template('viewdeletepatient.html', title='Patient\'s Details',results=patient,form=form)

@app.route("/deletepatient/<int:id>")
def deletepatient(id):
    patient=Patient.query.get_or_404(id)
    db.session.delete(patient)
    db.session.commit()
    return redirect(url_for('viewdeletepatient'))

@app.route("/searchpatientbyid", methods=['GET', 'POST'])
def searchpatientbyid():
    form = PatientSearchForm()
    if form.validate_on_submit():
        searchresult=Patient.query.filter_by(patientid=form.patientid.data).first()
        return render_template('searchpatientbyid.html', title='Patient\'s Details',searchresults=searchresult,form=form)
    return render_template('searchpatientbyid.html', title='Patient\'s Details',form=form)


@app.route("/diseasepredict/<int:id>",methods=['GET','POST'])
def diseasepredict(id):
    if request.method=='POST':
        search=Patient.query.filter_by(patientid=id).first()
        patientid = id
        patientname = search.patientname
        file = request.files.get('file')
        if not file:
            searchresult=Patient.query.filter_by(patientid=id).first()
            flash('Please upload a chest X-Ray Image of the patient..','danger')
            return render_template('diseasepredict.html', title='Prediction',searchresults=searchresult)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            print(app.config['uploads'])
            img = os.path.join(app.config['uploads'], filename)
            i = Image.open(file)
            i.save(img)
            prediction = predict_disease(patientid,patientname,img)
            return render_template('diseaseresult.html', result=prediction, title='Disease Prediction')
        else:
            searchresult=Patient.query.filter_by(patientid=id).first()
            flash('Only Images or Gif are allowed','danger')
            return render_template('diseasepredict.html', title='Prediction',searchresults=searchresult)
    searchresult=Patient.query.filter_by(patientid=id).first()
    return render_template('diseasepredict.html', title='Prediction',searchresults=searchresult)

@app.route("/generatereport/<int:id>/<message>",methods=['GET','POST'])
def generatereport(id,message):
    result=Patient.query.filter_by(patientid=id).first()
    output=[result.patientid,result.patientname,result.sex,result.age,result.phone,result.address,current_user.username,message]
    path= report_generate(output)
    patient = Patient.query.filter_by(patientid=id).first()
    patient.report = path
    db.session.commit()
    flash('Report Generated successfully..!', 'success')
    return redirect(url_for('viewpatient'))

@app.route("/viewpatient", methods=['GET', 'POST'])
def viewpatient():
    form = PatientSearchForm()
    if form.validate_on_submit():
        searchresult=Patient.query.filter_by(patientid=form.patientid.data).first()
        return render_template('viewpatient.html', title='Patient\'s Details',searchresults=searchresult,form=form)
    patient=Patient.query.all()
    return render_template('viewpatient.html', title='Patient\'s Details',results=patient,form=form)

@app.route("/downloadpdf/<id>",methods=['GET'])
def downloadpdf(id):
    #filepath=os.path.join(app.config['download'],id+'.pdf')
    filepath=os.path.join(app.config['download'],id+'.docx')
    return send_file(filepath,as_attachment=True)

@app.route("/openpdf/<id>",methods=['GET'])
def openpdf(id):
    folder=app.config['download']
    #return send_from_directory(folder,id+'.pdf')
    return send_from_directory(folder,id+'.docx')

def save_picture(form_picture):
    random_hex = secrets.token_hex(8)
    _, f_ext = os.path.splitext(form_picture.filename)
    picture_fn = random_hex + f_ext
    picture_path = os.path.join(app.root_path, 'static\profile', picture_fn)
    output_size = (175, 175)
    i = Image.open(form_picture)
    i.thumbnail(output_size)
    i.save(picture_path)
    return picture_fn





